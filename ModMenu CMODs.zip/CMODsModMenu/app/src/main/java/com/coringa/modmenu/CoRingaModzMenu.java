package com.coringa.modmenu;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.text.Spanned;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import static android.view.ViewGroup.LayoutParams.FILL_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Random;




import android.os.Build;

public class CoRingaModzMenu extends Service {
    private WindowManager mWindowManager;
    private View FlutuanteByCoRingaModz;
    private RelativeLayout mRootContainer, mCollapsed, ButtonLayout;
    private LinearLayout SwitchList, MenuEzCheatsYT, TitleLayout;
    public ImageView image;
    private WindowManager.LayoutParams params;
    public ScrollView Scroll;
    public TextView TitleText;

    public native String Title();
    public native String WebViewText();
    public native String closeButton();
    public native String Icon();
    private native String[] getFeatureList();
    public native void Changes(int feature, int value);

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        System.loadLibrary("CMODs");
        CoringamodzS(this);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                CoRingaModzMenu.this.Thread();
                handler.postDelayed(this, 1000);
            }
        });
    }


    private int dp2px(int dp) {
        final float scale = getResources().getDisplayMetrics().density;
        return (int) (dp * scale + 0.5f);
    }

    public void Thread() {
        if (this.FlutuanteByCoRingaModz == null) {
            return;
        }
        if (isAppBackground()) {
            this.FlutuanteByCoRingaModz.setVisibility(View.INVISIBLE);
        } else {
            this.FlutuanteByCoRingaModz.setVisibility(View.VISIBLE);
        }
    }

    public void CoringamodzS(Context context) {
        try {
            FrameLayout rootFrame = new FrameLayout(context);
            mRootContainer = new RelativeLayout(context);
            mCollapsed = new RelativeLayout(context);
            MenuEzCheatsYT = new LinearLayout(context);
            SwitchList = new LinearLayout(context);
            TitleLayout = new LinearLayout(context);
            Scroll = new ScrollView(context);
            image = new ImageView(context);
            ButtonLayout = new RelativeLayout(context);
            TitleText = new TextView(context);
            FrameLayout.LayoutParams flayoutParams = new FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
            rootFrame.setLayoutParams(flayoutParams);
            mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
            mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
            mCollapsed.setVisibility(View.VISIBLE);


//IMAGEM DO MENU TESTE
            image.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
            int dimension = 60;
            int dimensionInDp = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dimension, getResources().getDisplayMetrics());
            image.getLayoutParams().height = dimensionInDp;
            image.getLayoutParams().width = dimensionInDp;
            image.requestLayout();
            image.setScaleType(ImageView.ScaleType.FIT_XY);
            byte[] arrayOfByte1 = Base64.decode(Icon(), 0);
            Bitmap bitmap1 = BitmapFactory.decodeByteArray(arrayOfByte1, 0, arrayOfByte1.length);
            image.setImageBitmap(bitmap1);
            ((ViewGroup.MarginLayoutParams) this.image.getLayoutParams()).topMargin = this.dp2px(10);

//IMAGEM TESTE


            MenuEzCheatsYT.setVisibility(View.GONE);
            GradientDrawable bg = new GradientDrawable();
            setColor(bg,Color.MAGENTA);
            setCornerRadius(bg,20);
            setStroke(bg,6, Color.CYAN);
            MenuEzCheatsYT.setBackground(bg);
            MenuEzCheatsYT.setPadding(8,8,8,8);
            MenuEzCheatsYT.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams Mr_EzCheatsYT = new LinearLayout.LayoutParams(dp2px(220), dp2px(-2));
            MenuEzCheatsYT.setLayoutParams(Mr_EzCheatsYT);


//MODULO

            Scroll.setLayoutParams(new LinearLayout.LayoutParams(FILL_PARENT, dp2px(155)));
            SwitchList.setLayoutParams(new LinearLayout.LayoutParams(FILL_PARENT, FILL_PARENT));
            SwitchList.setOrientation(LinearLayout.VERTICAL);
            SwitchList.setPadding(8, 8, 8, 8);


            TitleLayout.setLayoutParams(new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
            TitleLayout.setGravity(Gravity.CENTER);
            TitleLayout.setOrientation(LinearLayout.VERTICAL);
            TitleText.setText(Title());
            TitleText.setTextColor(Color.WHITE);
            TitleText.setGravity(Gravity.CENTER);
            TitleText.setShadowLayer(20,0,0, Color.BLACK);
            TitleText.setTextSize(14f);
            TitleText.setTypeface(TitleText.getTypeface(),Typeface.BOLD);
            
            
            TextView webView = new TextView(context);
            webView.setBackgroundColor(Color.TRANSPARENT);
            webView.setVerticalScrollBarEnabled(false);
            webView.setHorizontalScrollBarEnabled(false);
            webView.setText(WebViewText());
			webView.setPadding(10, 10, 10, 10);
            LinearLayout.LayoutParams title_Layout = new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
            webView.setLayoutParams(title_Layout);
		
            TitleLayout.addView(TitleText);
            TitleLayout.addView(webView);


            ButtonLayout.setLayoutParams(new RelativeLayout.LayoutParams(-1, dp2px(65)));
            ButtonLayout.setPadding(10, 10, 10, 10);
            GradientDrawable closebg = new GradientDrawable();
            setColor(closebg,Color.TRANSPARENT);
            setStroke(closebg,4, Color.LTGRAY);
            setCornerRadius(closebg,10);
            Button CloseButton = new Button(this);
            CloseButton.setBackground(closebg);
            CloseButton.setText(closeButton());
            CloseButton.setTextColor(Color.WHITE);
            CloseButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    mCollapsed.setVisibility(View.VISIBLE);
                    MenuEzCheatsYT.setVisibility(View.GONE);
                }
            });
            ButtonLayout.addView(CloseButton);
            rootFrame.addView(mRootContainer);
            mRootContainer.addView(mCollapsed);
            mRootContainer.addView(MenuEzCheatsYT);
            mCollapsed.addView(image);
            MenuEzCheatsYT.addView(TitleLayout);
            MenuEzCheatsYT.addView(Scroll);
            Scroll.addView(SwitchList);
            MenuEzCheatsYT.addView(ButtonLayout);
            FlutuanteByCoRingaModz = rootFrame;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                params = new WindowManager.LayoutParams(
                        WRAP_CONTENT,
                        WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT);
            } else {
                params = new WindowManager.LayoutParams(
                        WRAP_CONTENT,
                        WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_PHONE,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT);
            }
            params.gravity = Gravity.CENTER | Gravity.CENTER;
            params.x = 0;
            params.y = 0;
            mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            mWindowManager.addView(FlutuanteByCoRingaModz, params);
            final View collapsedView = mCollapsed;
            final View expandedView = MenuEzCheatsYT;
            FlutuanteByCoRingaModz.setOnTouchListener(onTouchListener());
            image.setOnTouchListener(onTouchListener());
            InitBUTT(collapsedView, expandedView);
            MrEzCheatsList();
        } catch (Exception ex) {
            Toast.makeText(context, ex.toString(), Toast.LENGTH_LONG).show();
        }
    }
    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;

            final View expandedView = MenuEzCheatsYT;
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:

                        initialX = params.x;
                        initialY = params.y;

                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int Xdiff = (int) (event.getRawX() - initialTouchX);
                        int Ydiff = (int) (event.getRawY() - initialTouchY);

                        if (Xdiff < 10 && Ydiff < 10) {
                            if (isViewCollapsed()) {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                                //collapsedView.setAlpha(0.8f);//Menu Meio Transparent
								//expandedView.setAlpha(0.8f);//Menu Meio Transparent

                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);

                        mWindowManager.updateViewLayout(FlutuanteByCoRingaModz, params);
                        return true;
                }
                return false;
            }
        };
    }

    private void InitBUTT(final View collapsedView, final View expandedView) {
        image.setOnClickListener(new ImageView.OnClickListener() {
            @Override
            public void onClick(View view) {
                collapsedView.setVisibility(View.GONE);
                expandedView.setVisibility(View.VISIBLE);

            }
        });
    }

//||||||TESTE MENU

    private void MrEzCheatsList(){
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("Toggle_")) {
                addSwitch(str.replace("Toggle_", ""), new InterfaceBool() {
                        public void OnWrite(boolean z) {
                            Changes(feature, 0);
                        }
                    });
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("Button_")) {
                addButton(str.replace("Button_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });
            }
        }
    }
    private void addCategory(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.parseColor("WHITE"));
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.parseColor("RED"));
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(10, 5, 0, 5);
        SwitchList.addView(textView);
    }
    public void addButton(String feature, final InterfaceBtn interfaceBtn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 50);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setPadding(10, 5, 10, 5);
        button.setTextSize(12.0f);
        button.setTextColor(Color.parseColor("WHITE"));
        button.setGravity(17);
        if (feature.contains("OnOff_")) {
            feature = feature.replace("OnOff_", "");
            button.setText(feature + "   [OFF]");
            button.setBackgroundColor(Color.parseColor("MAGENTA"));
            GradientDrawable px = new GradientDrawable();
            px.setShape(GradientDrawable.RECTANGLE);
            px.setCornerRadius(8);
            px.setGradientType(GradientDrawable.LINEAR_GRADIENT);
            px.setStroke(3, (Color.parseColor("#000000")));
            px.setColor(Color.parseColor("MAGENTA"));
            button.setBackground(px);
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
                    private boolean isActive = true;
                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                        if (isActive) {
                            button.setText(feature2 + "   [ON]");
                            button.setBackgroundColor(Color.parseColor("#29a626"));
                            GradientDrawable bt = new GradientDrawable();
                            bt.setShape(GradientDrawable.RECTANGLE);
                            bt.setCornerRadius(8);  
                            bt.setGradientType(GradientDrawable.LINEAR_GRADIENT);
                            bt.setStroke(3, (Color.parseColor("#000000")));
                            bt.setColor(Color.parseColor("#29a626"));
                            button.setBackground(bt);
                            isActive = false;
                            return;
                        }
                        button.setText(feature2 + "   [OFF]");
                        button.setBackgroundColor(Color.parseColor("MAGENTA"));
                        GradientDrawable px = new GradientDrawable();
                        px.setShape(GradientDrawable.RECTANGLE);
                        px.setCornerRadius(8);
                        px.setGradientType(GradientDrawable.LINEAR_GRADIENT);
                        px.setStroke(3, (Color.parseColor("#000000")));
                        px.setColor(Color.parseColor("MAGENTA"));
                        button.setBackground(px);
                        isActive = true;
                    }
                });
        } else {
            button.setText(feature);
            button.setBackgroundColor(Color.parseColor("#FF0000"));
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                    }
                });
        }
        SwitchList.addView(button);
    }
    private void addSwitch(String feature, final InterfaceBool sw) {
        Switch switchR = new Switch(this);
        switchR.setBackgroundColor(Color.parseColor("#171E24"));
        switchR.setText(Html.fromHtml("<font face='roboto'>" + feature + "</font>"));
        switchR.setTextColor(Color.parseColor("#DEEDF6"));
        switchR.setPadding(10, 5, 0, 5);
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                     
                    } else {
                       
                    }
                    sw.OnWrite(z);
                }
            });
        SwitchList.addView(switchR);
    }

    private void addSeekBar(String str,  int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(18);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));
        TextView textView = new TextView(this);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("<font face='monospace'><b>");
        sb2.append(str);
        sb2.append("<font face='monospace'><b>" + ": <font color='GREEN'>" + "</b></font>");
        sb2.append(progress);
        sb2.append("</b></font>");
        textView.setText(Html.fromHtml(sb2.toString()));
        textView.setTextSize(15);
        textView.setTextColor(-1);
        textView.setTextColor(Color.WHITE);
        textView.setTypeface((Typeface) null, 1);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setScaleY(1.0f);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#3818c7"), PorterDuff.Mode.SRC_IN);
        seekBar.getThumb().setColorFilter(Color.parseColor("BLACK"), PorterDuff.Mode.SRC_IN);
        //textView.setShadowLayer(7.0f, 0.0f, 0.0f, Color.parseColor("WHITE"));

        if (Build.VERSION.SDK_INT >= 21) {
            seekBar.getProgressDrawable().setTint(-1);
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;
        final TextView textView2 = textView;
        final String str3 = str;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                private String itv;
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    int i2 = i5;
                    if (i < i2) {
                        seekBar2.setProgress(i2);
                        sb3.OnWrite(i5);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + str3 + ": <font color=WHITE'>" + i5 + "</b></font>"));
                        return;
                    }
                    sb3.OnWrite(i);
                    textView2.setText(Html.fromHtml("<font face='monospace'><b>" + str3 + ": <font color=WHITE'>" + i + "</b></font>"));

                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        SwitchList.addView(linearLayout);
    }

    public void setColor(GradientDrawable gradientDrawable, int color){
        gradientDrawable.setColor(color);
    }

    public void setStroke(GradientDrawable gradientDrawable, int width, int color){
        gradientDrawable.setStroke(width,color);
    }

    public void setCornerRadius(GradientDrawable gradientDrawable, float radius){
        gradientDrawable.setCornerRadius(radius);
    }

    public boolean isAppBackground() {
        ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    private boolean isViewCollapsed() {
        return FlutuanteByCoRingaModz == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return Service.START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (FlutuanteByCoRingaModz != null){
            mWindowManager.removeView(FlutuanteByCoRingaModz);
        }
    }
    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
    private interface SW {
        void OnWrite(boolean z);
    }

}
