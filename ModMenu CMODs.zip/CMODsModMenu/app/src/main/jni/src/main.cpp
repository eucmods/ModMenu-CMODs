#include <pthread.h>
#include <src/Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"

const char *libName = "libil2cpp.so";

bool Modding, MOD = false;

struct My_Patches {
    MemoryPatch BypassPtrace;
} Patches;

extern "C"
 {
    JNIEXPORT jstring JNICALL
    Java_com_coringa_modmenu_CoRingaModzMenu_closeButton(JNIEnv *env, jobject thiz) {
        return env->NewStringUTF("Close");
    }

    JNIEXPORT jstring JNICALL
    Java_com_coringa_modmenu_CoRingaModzMenu_Title(JNIEnv *env, jobject thiz) {
        return env->NewStringUTF("Mod By CRynzX");
    }

    JNIEXPORT jstring JNICALL
    Java_com_coringa_modmenu_CoRingaModzMenu_WebViewText(JNIEnv *env, jobject thiz) {
        return env->NewStringUTF("CoRinga Modz");
    }
    JNIEXPORT jobjectArray  JNICALL
    Java_com_coringa_modmenu_CoRingaModzMenu_getFeatureList(JNIEnv *env,jobject activityObject) {
        jobjectArray ret;
        const char *features[] = {
             "Button_OnOff_AIM BOT",//0
            "Button_OnOff_AIM TIRO",//1
            "Button_OnOff_AIM MIRA",//2
            "Button_OnOff_ESP FIRE",//6		
            "SeekBar_AIM SPOT_0_3",//3
            "SeekBar_AIM FOV_0_360",//4
            "SeekBar_AIM DISTANCIA_0_100",//5
	
        };

        int Total_Feature = (sizeof features /
                        sizeof features[0]);
        ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                         env->NewStringUTF(""));
        int i;
        for (i = 0; i < Total_Feature; i++)
            env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
        return (ret);
        }
    }
JNIEXPORT void JNICALL
Java_com_coringa_modmenu_CoRingaModzMenu_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint Value) {
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", Value);
    switch (feature) {      
       case 0:
       // CM.headshoot = !CM.headshoot;
        break;     
      case 1:
       // CM.Aimbot= !CM.Aimbot;
        break;      
      case 2:
       // CM.ESPLIne= !CM.ESPLIne;
        break;    
      case 3:
          //
        break;  
      case 4:
     //
        break;
      case 5:
          //
        break;
      case 6:
        //
         break;
}
}

void *LOADERCMODS(void *) {
    do {
        sleep(1);
    } while (!isLibraryLoaded(libName));
    LOGI("I found the il2cpp lib. Address is: %p", (void*)findLibrary(libName));
    //MSHookFunction((void*)getAbsoluteAddress(libName, 0x123456), (void *)CoRinga, (void **) &old_CoRinga);
    //Patches.BypassPtrace = MemoryPatch(libName,0x654321,"\x00\x00\xa0\xE3\x1E\xFF\x2F\xE1", 8);
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {

    pthread_t ptid;
    pthread_create(&ptid, NULL, LOADERCMODS, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
