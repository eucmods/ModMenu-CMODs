
OnCreate %%% Game Or UnityPlayerActivity

invoke-static {p0}, Lcom/coringa/modmenu/XStart;->Start(Landroid/content/Context;)V


Permission For Menu Floating%%%%

	<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />


Manifest Service
	<service android:name="com.coringa.modmenu.CoRingaModzMenu" 
android:enabled="true" 
android:exported="false" />




Telegram Contact 
@CoRingaModzYT
